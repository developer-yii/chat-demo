@extends('layouts.chat')

@section('content')
<div class="container content">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />
    <div class="container">
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card chat-app">
                    <div class="chat">
                        <div class="chat-header clearfix">
                            <div class="row">
                                <div class="col-lg-6">
                                    <a href="javascript:void(0);" data-toggle="modal" data-target="#view_info">
                                        <img src="https://bootdey.com/img/Content/avatar/avatar2.png" alt="avatar">
                                    </a>
                                    <div class="chat-about">
                                        <h6 class="m-b-0">John Doe</h6>
                                    </div>
                                </div>
                                <div class="col-lg-6 hidden-sm text-right" style="display: none;">
                                    <a href="javascript:void(0);" class="btn btn-outline-secondary"><i class="fa fa-camera"></i></a>
                                    <a href="javascript:void(0);" class="btn btn-outline-primary"><i class="fa fa-image"></i></a>
                                    <a href="javascript:void(0);" class="btn btn-outline-info"><i class="fa fa-cogs"></i></a>
                                    <a href="javascript:void(0);" class="btn btn-outline-warning"><i class="fa fa-question"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="chat-history hide">
                            <ul class="m-b-0">
                                @foreach($chat_data as $data)
                                    @php
                                        $float_right = $text_right = '';
                                        if($data->user_id == $user_id){
                                            $text_right = 'text-right';
                                            $float_right = 'float-right';
                                        }
                                    @endphp
                                <li class="clearfix">
                                    <div class="message-data {{ $text_right }}">
                                        <span class="message-data-time">{{ $data->message_time }}</span>
                                    </div>
                                    <div class="message other-message {{ $float_right }}"> {{ $data->message_text }} </div>
                                </li>
                                @endforeach
                            </ul>
                        </div>
                        <div class="chat-message clearfix">
                            <div class="input-group mb-0">
                                <input type="text" class="form-control input_box" placeholder="Enter text here...">                                    
                                
                                <input type="file" style="display:none;" id="file_input">

                                <div class="input-group-prepend">
                                    <span class="input-group-text input_file"><i class="fa fa-file"></i></span>
                                    <span class="input-group-text submit_btn"><i class="fa fa-send"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('js')

<script type="text/javascript">
    var sendMessage = "{{ route('sendMessage') }}";
    var pak = "{{ env('PUSHER_APP_KEY') }}";
    var pac = "{{ env('PUSHER_APP_CLUSTER') }}";
    var user_id = "{{ $user_id }}";
</script>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="https://js.pusher.com/7.1/pusher.min.js"></script>
<script type="text/javascript" src="{{ URL::asset('js/custom/chat.index.js') }}"></script></script>

@endsection



