<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Chat;
use Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }

    public function chat()
    {
        $chat_data = Chat::query()
            ->get();

        $user_id = Auth::id();

        return view('chat',compact('chat_data','user_id'));
    }

    public function sendMessage(Request $request)
    {

        $model = new Chat;
        $model->user_id = Auth::id();
        $model->message_time = date('Y-m-d H:i:s');

        if(isset($request->file) && !empty($request->file)){

            $filename = $request->file->getClientOriginalName();
            $extension = $request->file->getClientOriginalExtension();
            $filename = md5(rand(0,999999999).time());
            $newFileName = $filename.'.'.$extension;
            $dir = 'public/upload/';
            Storage::disk('local')->put($dir.$newFileName, \File::get($request->file('file')));

            $model->file_path = $newFileName;

            if(strtolower($extension) == 'jpeg' || strtolower($extension) == 'png' || strtolower($extension) == 'jpg'){
                $pusher_data = '<li class="clearfix"><div class="message-data"><span class="message-data-time">'.$model->message_time.'</span></div> <div class="message other-message"><img src='.asset('/storage/upload/'.$imageData->file_path).'></div></li>';    
            }else{

            }
        }else{
            $model->message_text = $request->input_text;    

            $pusher_data = '<li class="clearfix"><div class="message-data"><span class="message-data-time">'.$model->message_time.'</span></div> <div class="message other-message">'.$model->message_text.'</div></li>';
        }
        
        
        $model->save();

        

        $data_object = '<li class="clearfix"><div class="message-data text-right"><span class="message-data-time">'.$model->message_time.'</span></div> <div class="message other-message float-right">'.$model->message_text.'</div></li>';

        $pusher_data_array = [];
        $pusher_data_array['html'] = $pusher_data;
        $pusher_data_array['sender_user_id'] = $model->user_id;

        $this->pusherOrderUpdate(json_encode($pusher_data_array));

        $result = ['status' => true, 'message' => "Status update failed", 'data' => $data_object];
        return response()->json($result);
    }

    public function pusherOrderUpdate($data)
    {
        $options = array(
            'cluster' => env('PUSHER_APP_CLUSTER'),
            'useTLS' => true
        );

        $pusher = new \Pusher\Pusher(
            env('PUSHER_APP_KEY'),
            env('PUSHER_APP_SECRET'),
            env('PUSHER_APP_ID'),
            $options
        );

        $pusher->trigger('order-status-updated-channel', 'order-status-updated', $data);
    }
}
